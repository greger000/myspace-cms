# MySpace CMS — PWA Installation Guide (Updated)
## How to install your app on Android so it works offline forever

---

## What you need to upload (4 files total)
- `MySpace-CMS-PWA.html` — the app itself
- `manifest.json` — tells Chrome how to install it
- `icon-192.svg` — app icon
- `icon-512.svg` — app icon (large)

All four files must sit in the **same folder** on GitHub.

---

## Step 1 — First: uninstall the broken version

The old install is pointing to the wrong address (127.0.0.1). Remove it first:

1. On your Android home screen, **long-press** the MySpace icon
2. Tap **Uninstall** → confirm

Also clear it from Chrome:
1. Open Chrome → address bar → type: `chrome://apps`
2. If MySpace appears, long-press it → **Remove from Chrome**

---

## Step 2 — Upload all 4 files to GitHub

1. Go to **github.com** → open your `myspace-cms` repository
2. Click **Add file** → **Upload files**
3. Drag and drop all 4 files at once
4. Click **Commit changes**
5. Wait ~60 seconds for GitHub Pages to update

Your app URL stays the same:
```
https://YOUR-USERNAME.github.io/myspace-cms/MySpace-CMS-PWA.html
```

---

## Step 3 — Reinstall on your phone

1. Open **Chrome** on Android
2. Navigate to your GitHub Pages URL
3. Wait a few seconds — the **Install as App** banner appears at the bottom
4. Tap **Install**
5. Open the app from your home screen — no browser bar, no errors ✅

---

## Your posts are safe

IndexedDB data lives on your phone separately from the app files.
Uninstalling and reinstalling does **not** delete your posts.

Export first (Settings → Export) just to be safe.
